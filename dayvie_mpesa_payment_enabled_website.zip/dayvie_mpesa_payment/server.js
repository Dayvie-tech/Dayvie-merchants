require("dotenv").config();
const express = require("express");
const axios = require("axios");
const crypto = require("crypto");

const app = express();
app.use(express.json());
app.use(express.static("public"));

const PORT = process.env.PORT || 3000;
const ENV = process.env.DARAJA_ENV === "production" ? "production" : "sandbox";
const BASE = ENV === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

const services = {
  kra: { name: "KRA NIL Returns", min: 30, max: 30 },
  advice: { name: "Business Advice", min: 200, max: 5000 },
  digital: { name: "Digital Services", min: 1, max: 150000 }
};

const payments = new Map(); // Demo storage. Use a real DB before production.

function normalizePhone(value) {
  let p = String(value || "").replace(/\s+/g, "");
  if (p.startsWith("+254")) p = p.slice(1);
  if (p.startsWith("07") || p.startsWith("01")) p = "254" + p.slice(1);
  return /^254(7|1)\d{8}$/.test(p) ? p : null;
}

function timestamp() {
  const d = new Date();
  const pad = n => String(n).padStart(2, "0");
  return d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+
         pad(d.getHours())+pad(d.getMinutes())+pad(d.getSeconds());
}

async function getToken() {
  const key = process.env.DARAJA_CONSUMER_KEY;
  const secret = process.env.DARAJA_CONSUMER_SECRET;
  if (!key || !secret) throw new Error("Daraja credentials are not configured.");
  const auth = Buffer.from(`${key}:${secret}`).toString("base64");
  const r = await axios.get(`${BASE}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${auth}` }
  });
  return r.data.access_token;
}

app.get("/api/services", (req, res) => {
  res.json(services);
});

app.post("/api/mpesa/stkpush", async (req, res) => {
  try {
    const { service, amount, phone, name, email, details } = req.body;
    const item = services[service];
    const msisdn = normalizePhone(phone);
    const value = Number(amount);

    if (!item) return res.status(400).json({ ok:false, message:"Invalid service." });
    if (!Number.isInteger(value) || value < item.min || value > item.max) {
      return res.status(400).json({ ok:false, message:`Amount must be between KSh ${item.min} and KSh ${item.max}.` });
    }
    if (!msisdn) return res.status(400).json({ ok:false, message:"Enter a valid Kenyan M-PESA number." });

    if (!process.env.DARAJA_SHORTCODE || !process.env.DARAJA_PASSKEY || !process.env.DARAJA_CALLBACK_URL) {
      return res.status(503).json({ ok:false, message:"Payment gateway is not configured yet. Add your Daraja credentials and callback URL on the server." });
    }

    const token = await getToken();
    const time = timestamp();
    const password = Buffer.from(
      `${process.env.DARAJA_SHORTCODE}${process.env.DARAJA_PASSKEY}${time}`
    ).toString("base64");

    const reference = `DAYVIE-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;

    payments.set(reference, {
      reference, service, amount:value, phone:msisdn, name, email, details,
      status:"pending", createdAt:new Date().toISOString()
    });

    const payload = {
      BusinessShortCode: process.env.DARAJA_SHORTCODE,
      Password: password,
      Timestamp: time,
      TransactionType: "CustomerPayBillOnline",
      Amount: value,
      PartyA: msisdn,
      PartyB: process.env.DARAJA_SHORTCODE,
      PhoneNumber: msisdn,
      CallBackURL: process.env.DARAJA_CALLBACK_URL,
      AccountReference: reference,
      TransactionDesc: item.name
    };

    const r = await axios.post(`${BASE}/mpesa/stkpush/v1/processrequest`, payload, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const data = r.data;
    const record = payments.get(reference);
    record.merchantResponse = data;

    if (data.ResponseCode !== "0") {
      record.status = "failed";
      return res.status(400).json({ ok:false, message:data.ResponseDescription || "M-PESA could not start the prompt.", reference });
    }

    record.checkoutRequestID = data.CheckoutRequestID;
    record.merchantRequestID = data.MerchantRequestID;

    res.json({
      ok:true,
      reference,
      message:"M-PESA prompt sent. Check your phone and enter your M-PESA PIN."
    });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ ok:false, message:"Unable to start the M-PESA payment. Check the server configuration and try again." });
  }
});

app.post("/api/mpesa/callback", (req, res) => {
  console.log("M-PESA callback:", JSON.stringify(req.body));
  const result = req.body?.Body?.stkCallback;
  if (result) {
    const checkoutId = result.CheckoutRequestID;
    const record = [...payments.values()].find(x => x.checkoutRequestID === checkoutId);
    if (record) {
      record.resultCode = result.ResultCode;
      record.resultDescription = result.ResultDesc;
      record.status = Number(result.ResultCode) === 0 ? "paid" : "failed";
      if (Number(result.ResultCode) === 0) {
        const items = result.CallbackMetadata?.Item || [];
        record.receipt = items.find(x => x.Name === "MpesaReceiptNumber")?.Value || null;
      }
    }
  }
  res.json({ ResultCode: 0, ResultDesc: "Accepted" });
});

app.get("/api/payment/:reference", (req, res) => {
  const p = payments.get(req.params.reference);
  if (!p) return res.status(404).json({ ok:false, message:"Payment not found." });
  res.json({
    ok:true,
    reference:p.reference,
    status:p.status,
    service:p.service,
    amount:p.amount,
    receipt:p.receipt || null,
    message:p.status === "paid" ? "Payment received successfully." :
            p.status === "failed" ? (p.resultDescription || "Payment was not completed.") :
            "Waiting for M-PESA confirmation."
  });
});

app.listen(PORT, () => console.log(`Dayvie payment server running on port ${PORT}`));
