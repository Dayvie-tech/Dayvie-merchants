# Dayvie Merchants & Tech — M-PESA STK Push

This project contains:
- Responsive payment page
- Node/Express backend
- Safaricom Daraja OAuth
- STK Push request
- M-PESA callback handling
- Payment status polling
- Success/failure UI
- Service pricing

## Important
The `.env` file is intentionally NOT included. Copy `.env.example` to `.env` and put your Daraja credentials there.

Do not put Consumer Secret or Passkey in frontend JavaScript.

## Setup
1. Install Node.js 18+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Create/configure a Daraja app in the official Safaricom developer portal.
5. Put the credentials and a public HTTPS callback URL in `.env`.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Production
Before taking real payments:
- use HTTPS
- use a real database instead of the in-memory Map
- authenticate/admin-protect payment records
- validate callback data and maintain idempotency
- configure a real production callback URL
- complete Safaricom production onboarding/go-live
- verify the correct M-PESA merchant configuration for your business. If the intended receiving account is Pochi la Biashara, confirm with Safaricom/Daraja that the chosen API/product supports the exact Pochi flow; do not assume a phone number can be used as a normal STK shortcode.
